%{
#include <stdio.h>
#include <stdlib.h>

int yylex(void);              
int yyerror(const char *s);  
%}

%union {
    int val;
}

%token <val> BOOL
%token AND OR NOT

%left OR
%left AND
%right NOT

%type <val> expr

%%
input   :
        | input line
        ;

line    : '\n'
        | expr '\n'   { printf("= %s\n", $1 ? "true" : "false"); }
        ;

expr    : BOOL                { $$ = $1; }
        | '(' expr ')'        { $$ = $2; }
        | expr AND expr       { $$ = $1 && $3; }
        | expr OR expr        { $$ = $1 || $3; }
        | NOT expr            { $$ = !$2; }
        ;
%%

int main() {
    yyparse();
    return 0;
}

int yyerror(const char *s)   
{
    fprintf(stderr, "Error: %s\n", s);
    return 0;
}