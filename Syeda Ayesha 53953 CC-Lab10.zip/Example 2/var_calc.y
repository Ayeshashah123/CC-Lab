%{
#include <stdio.h>
#include <stdlib.h>

int yylex(void);              // ? FIX 1
int yyerror(const char *s);   // ? FIX 2

int sym[26];  /* symbol table for variables a..z */
%}

%token NUMBER VARIABLE
%left '+' '-'
%left '*' '/'

%%

input   : /* empty */
        | input line
        ;

line    : '\n'
        | expr '\n'              { printf("= %d\n", $1); }
        | VARIABLE '=' expr '\n' { sym[$1 - 'a'] = $3; }
        ;

expr    : NUMBER                { $$ = $1; }
        | VARIABLE              { $$ = sym[$1 - 'a']; }
        | expr '+' expr         { $$ = $1 + $3; }
        | expr '-' expr         { $$ = $1 - $3; }
        | expr '*' expr         { $$ = $1 * $3; }
        | expr '/' expr         { $$ = $1 / $3; }
        ;

%%

int main() {
    yyparse();
    return 0;
}

int yyerror(const char *s) {   // ? updated signature
    fprintf(stderr, "Error: %s\n", s);
    return 0;
}