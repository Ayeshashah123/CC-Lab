%{
#include <stdio.h>
#include <stdlib.h>

int yylex(void);
void yyerror(const char *s);
%}

/* Define data type */
%union {
    int num;
}

/* Tokens */
%token <num> NUMBER
%token PLUS MINUS TIMES DIVIDE LPAREN RPAREN

/* Precedence */
%left PLUS MINUS
%left TIMES DIVIDE

/* Type of non-terminals */
%type <num> expr

%%

input:
        /* empty */
      | input line
      ;

line:
        expr '\n'        { printf("= %d\n", $1); }
      | error '\n'       { printf("Invalid expression\n"); yyerrok; }
      ;

expr:
        NUMBER                  { $$ = $1; }
      | expr PLUS expr          { $$ = $1 + $3; }
      | expr MINUS expr         { $$ = $1 - $3; }
      | expr TIMES expr         { $$ = $1 * $3; }
      | expr DIVIDE expr        
        { 
            if ($3 == 0) {
                yyerror("Division by zero");
                $$ = 0;
            } else {
                $$ = $1 / $3;
            }
        }
      | LPAREN expr RPAREN      { $$ = $2; }
      ;

%%

int main() {
    printf("Simple Calculator (Ctrl+D to exit)\n");
    yyparse();
    return 0;
}

void yyerror(const char *s) {
    fprintf(stderr, "Error: %s\n", s);
}